# Demo Command for Changelog

Demo changelog automation features

## Instructions

1. This is a demonstration command
2. Shows changelog automation working independently
3. Bypasses Claude review bot for faster testing
