# frozen_string_literal: true

module SwarmMemory
  VERSION = "2.3.0"
end
