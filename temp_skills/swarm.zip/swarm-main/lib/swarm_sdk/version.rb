# frozen_string_literal: true

module SwarmSDK
  VERSION = "2.7.4"
end
