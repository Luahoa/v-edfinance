# frozen_string_literal: true

module SwarmCLI
  VERSION = "2.1.12"
end
