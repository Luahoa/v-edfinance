---
model: claude-opus-4-1
---

Improve an existing agent based on recent performance:

1. Analyze recent uses of: $ARGUMENTS
2. Identify patterns in:
   - Failed tasks
   - User corrections
   - Suboptimal outputs
3. Update the agent's prompt with:
   - New examples
   - Clarified instructions
   - Additional constraints
4. Test on recent scenarios
5. Save improved version
