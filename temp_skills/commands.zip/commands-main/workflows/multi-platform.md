---
model: claude-opus-4-1
---

Build the same feature across multiple platforms:

Run in parallel:
- frontend-developer: Web implementation
- mobile-developer: Mobile app implementation
- api-documenter: API documentation

Ensure consistency across all platforms.

Feature specification: $ARGUMENTS
